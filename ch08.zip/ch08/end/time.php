<?php
	date_default_timezone_set('America/Los_Angeles');
	echo date("F j, Y, g:i:s a");
?>